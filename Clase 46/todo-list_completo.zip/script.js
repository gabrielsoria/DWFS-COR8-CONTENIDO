// tarea = {
//     id:,
//     value:
// }

// Modelo
class Model {
    constructor() {
        this.tareas = []
    }

     add(tarea) {
        this.tareas.push(tarea)
        this.fnAviso(this.tareas)
    }

    avisar(callback) {
        this.fnAviso = callback
    }
}


// Vista
class View {
    constructor(){
    }

    onAgregar(callback) {
        let button = document.getElementById("btnTodo")
        let texto = document.getElementById("txtTodo")

        button.addEventListener("click", ()=> {
            callback(texto.value)
        })
    }

    mostrar(tareas) {

        let ul = document.getElementById("ulList")
        ul.innerHTML = ""

        tareas.forEach(element => {
            let li = document.createElement("li")
            li.innerHTML = element.value

            ul.appendChild(li)
            
        });
    }

}


// Controlador
class Controller {
    constructor(modelo, vista) {
        this.modelo = modelo
        this.vista = vista

        this.modelo.avisar(this.mostrar)
        this.vista.onAgregar(this.agregarTarea)
    }

    agregarTarea = (texto) =>  {
        let tarea = {
            id: 1,
            value: texto
        }

        this.modelo.add(tarea)
    }

    mostrar = (tareas) => {
        this.vista.mostrar(tareas)
    }
}

var app = new Controller(new Model(), new View())